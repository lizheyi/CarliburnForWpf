﻿using MahApps.Metro.Controls;
using System;
using System.Globalization;
using System.Windows.Data;

namespace $safeprojectname$.Converters
{
    public class HamburgerMenuItemToView : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value==null)
            {
                return null;
            }
            else
            {
                IView iview = value as IView;
                if (iview != null)
                {
                    return iview.Tag;
                }
                else
                {
                    return null;
                }
            }
            
            
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return ((HamburgerMenuIconItem)value).Tag;
        }
    }
}