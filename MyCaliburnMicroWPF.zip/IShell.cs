namespace $safeprojectname$
{
    public interface IShell
    {
        string Name { get; set; }

        void OpenView();
    }
}