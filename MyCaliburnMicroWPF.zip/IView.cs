﻿using $safeprojectname$.Framework;
using MahApps.Metro.IconPacks;
using System.Collections.Generic;

namespace $safeprojectname$
{
    public interface IView : IActivate, IHaveDisplayName, IDeactivate
    {
        List<IView> ChildView { get; set; }
        PackIconModernKind Icon { get; set; }
        string Label { get; set; }

        string Log { get; set; }
        object Tag { get; set; }

        void Append(string str);
    }
}