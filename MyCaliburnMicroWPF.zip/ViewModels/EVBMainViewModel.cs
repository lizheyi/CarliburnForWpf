﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.Framework;
using MahApps.Metro.IconPacks;
using $safeprojectname$.Models;
using System.Windows.Controls;

namespace $safeprojectname$.ViewModels
{
    public class EVBMainViewModel :Screen, IView
    {
        private List<Car> _listCars;

        public List<Car> ListCars
        {
            get { return _listCars; }
            set {
                _listCars = value;
                NotifyOfPropertyChange(()=> ListCars);
            }
        }

        private Car _currentSelectItem;

        public Car CurrentSelectItem
        {
            get { return _currentSelectItem; }
            set {
                _currentSelectItem = value;
                NotifyOfPropertyChange(()=>CurrentSelectItem);
            }
        }


        public EVBMainViewModel(string displayName, PackIconModernKind icon)
        {
            this.DisplayName = displayName;
            this.Icon = icon;
            _listCars = new List<Car>()
            {
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="200", Year="1990"},
                new Car(){ AutoMark="BENZ", Name="BENZ", TopSpeed="250", Year="1998"},
                new Car(){ AutoMark="BMW", Name="Audi", TopSpeed="300", Year="2002"},
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="350", Year="2011"},
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="500", Year="2020"},
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="200", Year="1990"},
                new Car(){ AutoMark="BENZ", Name="BENZ", TopSpeed="250", Year="1998"},
                new Car(){ AutoMark="BMW", Name="Audi", TopSpeed="300", Year="2002"},
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="350", Year="2011"},
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="500", Year="2020"},
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="200", Year="1990"},
                new Car(){ AutoMark="BENZ", Name="BENZ", TopSpeed="250", Year="1998"},
                new Car(){ AutoMark="BMW", Name="Audi", TopSpeed="300", Year="2002"},
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="350", Year="2011"},
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="500", Year="2020"},
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="200", Year="1990"},
                new Car(){ AutoMark="BENZ", Name="BENZ", TopSpeed="250", Year="1998"},
                new Car(){ AutoMark="BMW", Name="Audi", TopSpeed="300", Year="2002"},
                new Car(){ AutoMark="Audi", Name="Audi", TopSpeed="350", Year="2011"},
            };
            CurrentSelectItem = _listCars.ElementAt(10);           
        }

        public void SelectionChanged(object sender)
        {
            var listBox = sender as ListBox;
            if (listBox!=null)
            {
                //listBox.SelectionChanged
                listBox.ScrollIntoView(CurrentSelectItem);
            }
        }
        public List<IView> ChildView { get; set; }

        public string DisplayName { get; set; }      

        public PackIconModernKind Icon { get; set; }

        public bool IsActive { get; set; }

        public string Label { get; set; }

        public string Log { get; set; }

        public object Tag { get; set; }

        public event EventHandler<ActivationEventArgs> Activated;
        public event EventHandler<DeactivationEventArgs> AttemptingDeactivation;
        public event EventHandler<DeactivationEventArgs> Deactivated;

        public void Activate()
        {
            
        }

        public void Append(string str)
        {
            
        }

        public void Deactivate(bool close)
        {
            
        }
    }
}
