﻿using $safeprojectname$.Framework;
using MahApps.Metro.IconPacks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.ViewModels
{
    public class TabViewModel : Screen, IView
    {
        public TabViewModel(string displayName, PackIconModernKind icon)
        {            
            Header = displayName;
            Icon = icon;
            DisplayName = displayName;
        }
        public string Header { get; set; }
        public List<IView> ChildView { get; set; }
        public PackIconModernKind Icon { get; set; }
        public string Label { get; set; }
        public string Log { get; set; }
        public object Tag { get; set; }

        public void Append(string str)
        {
        }
    }
}
