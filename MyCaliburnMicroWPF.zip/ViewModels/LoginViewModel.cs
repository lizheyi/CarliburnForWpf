﻿using $safeprojectname$.Framework;
using $safeprojectname$.Properties;
using $safeprojectname$.Views;
using MahApps.Metro.Controls;
using MahApps.Metro.Controls.Dialogs;
using System;
using System.ComponentModel.Composition;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace $safeprojectname$.ViewModels
{
    [Export(typeof(IShell))]
    public class LoginViewModel : Screen, IShell
    {
        private readonly IWindowManager iWindowManager;
        private ImageBrush _backGround;

        private string _name = "LoginView";

        private string _password;

        private string _userNo;

        [ImportingConstructor]
        public LoginViewModel(IWindowManager windowManager)
        {
            iWindowManager = windowManager;
            
            //_userNo = "123";
            //_password = "123";
            BackGround = new ImageBrush();

            BackGround.ImageSource = new BitmapImage(new Uri(@"C:\Users\Public\Pictures\Sample Pictures\Penguins.jpg"));
        }

        public ImageBrush BackGround
        {
            get { return _backGround; }
            set { _backGround = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }

        public string UserNo
        {
            get { return _userNo; }
            set { _userNo = value; }
        }

        public void Cancel()
        {
            this.TryClose();
        }

        public void Confirm()
        {
            MainViewModel mainView = new MainViewModel(iWindowManager);
            mainView.OpenView();
            this.TryClose();
        }

        public void OpenView()
        {
        }

        protected override void OnViewLoaded(object view)
        {
            base.OnViewLoaded(view);
        }

        public async void Show(object sender)
        {
            var mainView = IoC.GetInstance(typeof(IShell),"MainView");           
            var metro = Application.Current.MainWindow as MetroWindow;
            MessageDialogResult mdr = await DialogManager.ShowMessageAsync(metro, "登录", "登陆成功");
            //MainViewModel mainView = new MainViewModel(iWindowManager);
            //mainView.OpenView();
            iWindowManager.ShowWindow(mainView);
            this.TryClose();
        }
    }
}