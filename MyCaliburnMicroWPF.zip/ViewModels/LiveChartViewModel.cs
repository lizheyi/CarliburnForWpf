﻿
#region 引用
using System;
using System.Collections.Generic;
using $safeprojectname$.Framework;
using MahApps.Metro.IconPacks;
using $safeprojectname$.Models;

using System.Windows.Controls;
using System.Linq;
#endregion

namespace $safeprojectname$.ViewModels
{
    public class LiveChartViewModel : Screen, IView
    {
        
        public List<IView> ChildView { get; set; }

        public string DisplayName { get; set; }

        public PackIconModernKind Icon { get; set; }

        public bool IsActive { get; set; }

        public string Label { get; set; }

        public string Log { get; set; }

        public object Tag { get; set; }

        private IEnumerable<SampleGroupVm> _sample;

        public IEnumerable<SampleGroupVm> Samples
        {
            get { return _sample; }
            set {
                _sample = value;
                NotifyOfPropertyChange(()=>Samples);
            }
        }

        private bool _isMenuOpen;

        public bool IsMenuOpen
        {
            get { return _isMenuOpen; }
            set { _isMenuOpen = value; }
        }

        private string _criteria;

        public string Criteria
        {
            get { return _criteria; }
            set {
                _criteria = value;
                NotifyOfPropertyChange(()=>Criteria);
                OnCriteriaChanged();
            }
        }

        private UserControl _content;

        public UserControl Content
        {
            get { return _content; }
            set {
                _content = value;
                NotifyOfPropertyChange(()=>Content);
            }
        }

        private IEnumerable<SampleGroupVm> _sampleTmp;

        public IEnumerable<SampleGroupVm> SampleTmp
        {
            get { return _sampleTmp; }
            set { _sampleTmp = value; }
        }


        public event EventHandler<ActivationEventArgs> Activated;
        public event EventHandler<DeactivationEventArgs> AttemptingDeactivation;
        public event EventHandler<DeactivationEventArgs> Deactivated;

        public void Activate()
        {
           
        }

        public void Append(string str)
        {
            //this.Log += $"\r\n{DateTime.Now}: {str}";
            //this.NotifyOfPropertyChange(nameof(this.Log));
        }

        public void Deactivate(bool close)
        {
           
        }

        protected override void OnActivate()
        {
            this.Append("OnActivate");
            base.OnActivate();
        }

        public LiveChartViewModel(string displayName, PackIconModernKind icon)
        {
            
        }

        public void UIElement_OnMouseDown(object sender)
        {
            var sample = (SampleVm)sender;
            this.Content = (UserControl)Activator.CreateInstance(sample.Content);
            this.IsMenuOpen = false;
        }

        private void OnCriteriaChanged()
        {
            if (string.IsNullOrWhiteSpace(Criteria))
            {
                Samples = SampleTmp;
                return;
            }

            Samples = Samples.Select(x => new SampleGroupVm
            {
                Name = x.Name,
                Items = x.Items.Where(y => y.Title.ToLowerInvariant().Contains(Criteria.ToLowerInvariant()) ||
                                           y.Tags.ToLowerInvariant().Contains(Criteria.ToLowerInvariant()))
            });
        }
    }
}
