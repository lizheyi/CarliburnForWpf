﻿using $safeprojectname$.Framework;
using $safeprojectname$.Models;
using MahApps.Metro.IconPacks;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Controls;
using System.Windows.Data;

namespace $safeprojectname$.ViewModels
{
    public class AddViewModel : Conductor<IView>.Collection.OneActive, IView
    {
        List<MenuTemplate> list;
        public AddViewModel(string displayName, PackIconModernKind icon)
        {
            this.DisplayName = displayName;
            this.Icon = icon;
            //oc = new ObservableCollection<IView>();
            //oc.Add(new TabViewModel("用户权限设置", PackIconModernKind.Add));
            //this.Items.Add(new TabViewModel("用户权限设置", PackIconModernKind.Add));
            list = new List<MenuTemplate>();
            MenuTemplate mt = new MenuTemplate();
            mt.MenuName = "设置";
            mt.SubMenuName = "用户权限设置";
            mt.Icon = PackIconModernKind.User;
            mt.SubMenuViewInstance = new TabViewModel("用户权限设置", PackIconModernKind.Add);
            this.Items.Add(mt.SubMenuViewInstance);

            MenuTemplate mt2 = new MenuTemplate();
            mt2.MenuName = "设置";
            mt2.SubMenuName = "基本设置";
            mt2.SubMenuViewInstance = new TabViewModel("基本设置", PackIconModernKind.Add);
            this.Items.Add(mt2.SubMenuViewInstance);
            mt2.Icon = PackIconModernKind.Settings;

            MenuTemplate mt1 = new MenuTemplate();
            mt1.MenuName = "测试";
            mt1.SubMenuName = "运行调试";
            mt1.SubMenuViewInstance = new TabViewModel("运行调试", PackIconModernKind.Add);
            this.Items.Add(mt1.SubMenuViewInstance);
            mt1.Icon = PackIconModernKind.VectorPen;

            MenuTemplate mt3 = new MenuTemplate();
            mt3.MenuName = "测试";
            mt3.SubMenuName = "调试";
            mt3.SubMenuViewInstance = new TabViewModel("调试", PackIconModernKind.Add);
            this.Items.Add(mt3.SubMenuViewInstance);
            mt3.Icon = PackIconModernKind.Check;

            list.Add(mt);
            list.Add(mt1);
            list.Add(mt2);
            list.Add(mt3);
            MenuList = new ListCollectionView(list);
            var group = new PropertyGroupDescription("MenuName");
            MenuList.GroupDescriptions.Add(group);
        }

        public List<IView> ChildView { get; set; }

        public PackIconModernKind Icon { get; set; }
        public string Label { get; set; }
        public string Log { get; set; }
        public ListCollectionView MenuList { get; set; }

        public ObservableCollection<IView> oc { get; set; }
        public object Tag { get; set; }

        //public ObjectDataProvider ActiveItem { get; set; }
        public object ListBoxSelectItem { get; set; }

        public void Append(string str)
        {
        }

        public void SubMenuButtonClick(string subMenuName)
        {
            object item = ListBoxSelectItem;
            var iView = list.Find(p => p.SubMenuName == subMenuName).SubMenuViewInstance;
            this.Items.Clear();
            this.Items.Add(iView);
            this.ActiveItem = iView;
        }
    }
}