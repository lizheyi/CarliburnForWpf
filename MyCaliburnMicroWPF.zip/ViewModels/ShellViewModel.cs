using $safeprojectname$.Framework;
using System;
using System.ComponentModel.Composition;
using System.Windows;

namespace $safeprojectname$
{
    [Export(typeof(IShell))]
    public class ShellViewModel : PropertyChangedBase, IShell
    {
        private int _count = 10;
        private string _name = "ShellView";

        public int Count
        {
            get { return _count; }
            set
            {
                _count = value;
                NotifyOfPropertyChange(() => Count);
            }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public void Add()
        {
            _count++;
        }

        public void OpenView()
        {
            throw new NotImplementedException();
        }

        public void Show(string msg)
        {
            MessageBox.Show("Hello" + msg);
        }
    }
}