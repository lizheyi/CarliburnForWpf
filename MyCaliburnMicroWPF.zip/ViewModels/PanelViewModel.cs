﻿using $safeprojectname$.Framework;
using MahApps.Metro.IconPacks;
using System;
using System.Collections.Generic;

namespace $safeprojectname$.ViewModels
{
    public class PanelViewModel : Screen, IView
    {
        public PanelViewModel(string displayName, PackIconModernKind icon)
        {
            this.DisplayName = displayName;
            this.Icon = icon;
            ChildView = new List<IView>();
            //IView iView5 = new PanelViewModel("Acorn", PackIconModernKind.Acorn);
            IView iView6 = new AddViewModel("Add", PackIconModernKind.Add);
            //ChildView.Add(iView5);
            ChildView.Add(iView6);
        }

        public event EventHandler<ActivationEventArgs> Activated;

        public event EventHandler<DeactivationEventArgs> AttemptingDeactivation;

        public event EventHandler<DeactivationEventArgs> Deactivated;

        public List<IView> ChildView { get; set; }

        public string DisplayName { get; set; }

        public PackIconModernKind Icon { get; set; }

        public bool IsActive
        {
            get;
            set;
        }

        public string Label { get; set; }

        public string Log { get; set; }

        public object Tag { get; set; }

        public void Activate()
        {
        }

        public void Append(string str)
        {
            
        }

        public void Deactivate(bool close)
        {
        }

        protected override void OnActivate()
        {
            this.Append("OnActivate");
            base.OnActivate();
        }
    }
}