﻿using $safeprojectname$.Framework;
using MahApps.Metro.Controls;
using MahApps.Metro.Controls.Dialogs;
using MahApps.Metro.IconPacks;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Windows;

namespace $safeprojectname$.ViewModels
{
    [Export(typeof(IShell))]
    public class MainViewModel : Conductor<IView>.Collection.OneActive, IShell
    {
        private readonly IWindowManager windowManager;
        private string _name = "MainView";

        private bool _settingsFlyoutIsOpen;

        [ImportingConstructor]
        public MainViewModel(IWindowManager wmanager)
        {
            MainTitle = "";
            windowManager = wmanager;

            //var loginView = IoC.GetInstance(typeof(IShell), "LoginView");
            //IoC.BuildUp(loginView);
            IView iView1 = new PanelViewModel("Acorn", PackIconModernKind.Acorn);
            IView iView2 = new AddViewModel("Setting", PackIconModernKind.Settings);
            IView iView3 = new PanelViewModel("ArrowRight", PackIconModernKind.ArrowRight);
            IView iViewLiveChart = new LiveChartViewModel("Live-Chart",PackIconModernKind.Chat);
            IView iEvbView = new EVBMainViewModel("EVBMainView",PackIconModernKind.TransitCar);
            this.Items.Add(iView1);
            this.Items.Add(iView2);
            this.Items.Add(iView3);
            this.Items.Add(iViewLiveChart);
            this.Items.Add(iEvbView);
        }

        public string MainTitle
        {
            get;
            private set;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public bool SettingsFlyoutIsOpen
        {
            get { return _settingsFlyoutIsOpen; }
            set { _settingsFlyoutIsOpen = value; }
        }

        private bool _isOpen;

        public bool IsOpen
        {
            get { return _isOpen; }
            set {
                _isOpen = value;
                NotifyOfPropertyChange(() => IsOpen);
            }
        }

        
        public async void OpenView()
        {
            windowManager.ShowWindow(this);
            var metro = windowManager.CurrentInstance as MetroWindow;
            MessageDialogResult mdr = await metro.ShowMessageAsync("Welcome", "Welcome Back！");
        }

        protected async override void OnViewLoaded(object view)
        {
            var metro = windowManager.CurrentInstance as MetroWindow;
            MessageDialogResult mdr = await metro.ShowMessageAsync("Welcome", "Welcome Back！");
            base.OnViewLoaded(view);
        }

        public async void Check()
        {           
            if (IsOpen)
                IsOpen = false;
            else
            {
                var metro = windowManager.CurrentInstance as MetroWindow;
                LoginDialogData ldd = await metro.ShowLoginAsync(
                    "Login", 
                    "Please input password", 
                    new LoginDialogSettings()
                    {
                        PasswordWatermark = "Please enter password"
                    }
                    );

                if (ldd.Password != "123")
                    IsOpen = false;
                else
                    IsOpen = true;
            }
            
        }
    }
}