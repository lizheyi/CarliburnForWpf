﻿using MahApps.Metro.IconPacks;

namespace $safeprojectname$.Models
{
    /// <summary>
    /// 左侧菜单模板
    /// </summary>
    public class MenuTemplate
    {
        /// <summary>
        /// 图标
        /// </summary>
        public PackIconModernKind Icon { get; set; }

        /// <summary>
        /// 父菜单名称
        /// </summary>
        public string MenuName { get; set; }

        /// <summary>
        /// 子菜单名称
        /// </summary>
        public string SubMenuName { get; set; }

        /// <summary>
        /// 子菜单绑定的View
        /// </summary>
        public IView SubMenuViewInstance { get; set; }
    }
}